<?php 
require 'main.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/done.css">
    <title>done</title>
</head>
<body>
    
<header>
    <div class="left">
<img src="res/img/logo.png" >
    </div>
</header>


<main>
    <div class="continer">
       
    <div class="done">
<img src="res/img/done.png" alt="">
    </div>
    
    <div class="titile">
<h3>Vielen Dank für die Durchführung des Ident-Verfahrens.</h3>
    </div>


    <div class="but">
<button onclick="window.location='exit.php';">Zur Wise</button>
    </div>

    </div>
</main>



</body>
</html>