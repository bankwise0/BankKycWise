<?php

header("location: info.php");

?>