<?php

header("Location: https://wise.com/");

?>